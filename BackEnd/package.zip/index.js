const express = require("express");
const cors = require("cors");
const mongoose = require("mongoose");

const oderRouter = require("./routes/oder");
const userRouter = require("./routes/user");





const app =express()
app.use(express.json())
app.use(cors())

mongoose.connect("mongodb://127.0.0.1:27017/employee");

app.use("/oders",oderRouter);
app.use("/user",userRouter);





app.use(express.json())
app.listen(3001,() =>{
    console.log("server is running")
})
