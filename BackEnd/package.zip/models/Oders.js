const mongoose = require("mongoose");

const oderSchema = new mongoose.Schema(
    {
        name:{type:String,required:true,},
        size:{type:String,required:true,},
        count:{type:Number,required:true,},
        userOwner:{type:mongoose.Schema.Types.ObjectId,
                    ref:"employee"},
        prise:{type:Number,}
    }
)
 
const OderModel = mongoose.model("oder",oderSchema)
module.exports = OderModel;

