import { Link, useNavigate } from "react-router-dom";
import {useCookies} from "react-cookie";

export const Navbar =() =>{

    const [cookies, setCookies] = useCookies(["access_token"]);
    const navigate = useNavigate();

    const logout = () =>{
        setCookies("access_token","");
        window.localStorage.clear();
        navigate("/login");
    }
return(
    <div>
              <Link to="/home"> Home </Link>
              <Link to="/signup"> SignUP </Link>
              <Link to="/login"> LogIn </Link>
              <Link to ="/dashboard"> Dash</Link>
              <Link to = "/paymentmethord">PaymentMethod</Link>
              <Link to = "/adress">adres s</Link>
              {/* <Link to ="/thankyou">Thank</Link> */}
              <Link to ="/admin">Admin</Link>
              {!cookies.access_token ? (
        <Link to="/login">Logout</Link>
      ) : (
        <button onClick={logout}> Logout </button>
      )}
    </div>
);
};