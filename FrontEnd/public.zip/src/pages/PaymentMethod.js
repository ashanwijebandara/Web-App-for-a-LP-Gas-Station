import { useState } from "react";

import axios from 'axios';


export const PaymentMethod =() =>{
    const[name, setName] = useState()
    const[cvv, setCvv] = useState()
    const[number, setNumber] = useState()

    const handleSubmit =(e) => {
      e.preventDefault()
      axios.post('http://localhost:3001/payment',{name,cvv,number})
      .then(result => console.log(result)
      )
      .catch(err => console.log(err))

    }
    return( 
        <div className="background_image-other">
        <div className="d-flex justify-content-left align-items-center  vh-90px">
         <div className="bg-transparent p-3 rounded w-25">
        
          <h2>
           Card Payment  
          </h2>
          <form onSubmit={handleSubmit}>
            <div className="mb-3">
              <label htmlFor="email">
                <strong>Name</strong>
              </label>
              <input type="text"
              placeholder="Enter Name"
              
              name="name"
              className="form-control rounded-0"
              onChange={(e) => setName(e.target.value)}
              />

            </div> 

            

            <div className="mb-3">
              <label htmlFor="email">
                <strong>Card Number</strong>
              </label>
              <input type="text"
              placeholder="Enter number"
              name="number"
              className="form-control rounded-0"
              onChange={(e) => setNumber(e.target.value)}/>
            </div>
            <div className="mb-3">
              <label htmlFor="email">
                <strong>CVV</strong>
              </label>
              <input type="cvv"
              placeholder="Enter CVV"
             
              name="email"
              className="form-control rounded-0"
              onChange={(e) => setCvv(e.target.value)}/>
            </div>
            <button type="submit" className="btn btn-success border w-100  rounded-8 text-decoration-none">
              Pay
            </button>

          </form>
         

          </div>
          </div>
        </div>
    );
};