

export const ThankYou = () =>{
    return(
        <div className="background_image-other">
                <h1> Thank You</h1>
                <p>If you give us your empty cylinder you will get 25% discount</p>
        </div>
        
    );
};