const express = require("express");

const EmployeeModel = require("../models/Employee");
const OderModel = require("../models/Oders");

const router = express.Router();

router.get("/", async (req, res) => {
    try {
        const result = await OderModel.find(); // Await the find() call to get the results
        res.status(200).json(result);
        console.log(result);
    } catch (err) {
        res.status(500).json(err);
    }
});



// Create a new oder

router.post("/",async (req, res) => {
    console.log(req.body)
  
    
    const oder = new OderModel ({
        
        name: req.body.name,
        size: req.body.size,
        count: req.body.count,
        userOwner: req.body.userOwner,
        prise: req.body.prise,
    });
    

    try {
        const result = oder.save();  
        res.status(201).json({oder})
    } catch (err) {
        res.status(500).json(err);
    }
});

// Get oder by id
router.get("/:orderId", async (req, res) => {
    try {
        const order = await OderModel.findById(req.params.orderId);

        if (!order) {
            return res.status(404).json({ message: 'Order not found' });
        }

        res.status(200).json({ order });
    } catch (err) {
        console.error(err);
        res.status(500).json({ message: 'Internal server error' });
    }
});

// place a Oder

router.put("/",async (req,res,next)=>{
    const oder =await OderModel.findById(req.body.oderId)
    const user = await EmployeeModel.findById(req.body.userID)
    try {
        if (!user.savedOders) {
            user.savedOders = [];  
        }
    
        user.savedOders.push(oder);  
        await user.save();
    
        res.status(201).json({ savedOders: user.savedOders });
    } catch (err) {
        next(err);
        res.status(500).json(err);
    }
})

//Get oders of user

router.get("/savedOders/:userId",async (req,res)=>{
    try {
        const user = await EmployeeModel.findById(req.params.userId)
            .populate('savedOders', 'name count price'); // Populate order details

        if (!user) {
            return res.status(404).json({ message: 'User not found' });
        }

        const orders = user.savedOders.map(order => ({
            name: order.name,
            count: order.count,
            price: order.price  // Using 'price' for the response
        }));
        
        res.status(200).json({ savedOders: orders });
        
    } catch (err) {
        console.error(err);
        res.status(500).json({ message: 'Internal server error' });
    }
})

//Get oders

/* router.get("/orders/:orderId", async (req, res) => {
    try {
        const order = await OderModel.findById(req.params.orderId);

        if (!order) {
            return res.status(404).json({ message: 'Order not found' });
        }

        res.status(200).json({ order });
    } catch (err) {
        console.error(err);
        res.status(500).json({ message: 'Internal server error' });
    }
}); */

//delete a order by id
router.delete("/:orderId", async (req, res) => {
    const orderId = req.params.orderId;

    try {
        // Find and delete the order
        const deletedOrder = await OderModel.findByIdAndDelete(orderId);

        if (!deletedOrder) {
            return res.status(404).json({ message: 'Order not found' });
        }

        // Remove the order ID from the user's saved orders
        const user = await EmployeeModel.findById(deletedOrder.userOwner);
        if (user) {
            user.savedOders = user.savedOders.filter(savedOrderId => savedOrderId.toString() !== orderId);
            await user.save();
        }

        res.status(200).json({ message: 'Order deleted successfully' });
    } catch (err) {
        console.error(err);
        res.status(500).json({ message: 'Internal server error' });
    }
});

router.delete("/savedOders/:userId/:orderId", async (req, res) => {
    const userId = req.params.userId;
    const orderId = req.params.orderId;

    try {
        const user = await EmployeeModel.findById(userId);

        if (!user) {
            return res.status(404).json({ message: 'User not found' });
        }

        // Check if the order ID is in the user's saved orders
        const orderIndex = user.savedOders.findIndex(order => order.toString() === orderId);

        if (orderIndex === -1) {
            return res.status(404).json({ message: 'Order not found for this user' });
        }

        // Remove the order ID from the user's saved orders
        user.savedOders.splice(orderIndex, 1);
        await user.save();

        // Delete the order
        const deletedOrder = await OderModel.findByIdAndDelete(orderId);

        if (!deletedOrder) {
            return res.status(404).json({ message: 'Order not found' });
        }

        res.status(200).json({ message: 'Order deleted successfully' });
    } catch (err) {
        console.error(err);
        res.status(500).json({ message: 'Internal server error' });
    }
});


module.exports = router; 
