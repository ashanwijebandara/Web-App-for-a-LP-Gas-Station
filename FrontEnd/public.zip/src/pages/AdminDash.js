
/* 

export const AdminDashboard = () =>{
    return(
        <div className="background_image-other">
                <h1> Admin dash</h1>
        </div>
        
    );
}; */

//import React, { useState, useEffect } from 'react';
//import axios from 'axios';
import '../index';

/* 
export const AdminDashboard = () => {
  const [usersWithOrders, setUsersWithOrders] = useState([]);

  useEffect(() => {
    const fetchUsersWithOrders = async () => {
      try {
        const response = await axios.get('http://localhost:3001/user/');
        setUsersWithOrders(response.data);
      } catch (error) {
        console.error('Error fetching users with orders:', error);
      }
    };

    fetchUsersWithOrders();
  }, []); // Run this effect only once when the component mounts

  return (
    <div className="background_image-other">
      <h2>Users with Orders</h2>
      <ul class="order-list">
        {usersWithOrders.map((user) => (
          <li key={user.user._id}>
            <span class="label">Name:</span> {user.user.name}, <span class="label">Email:</span> {user.user.email}
            <ul class="order-list">
              {user.savedOders.map((order) => (
                <li key={order._id}>
                  <span class="label">Order Name:</span> {order.name},
                   <span class="label">Size:</span> {order.size}, 
                  <span class="label">Count:</span> {order.count}, 
                  <span class="label">Price:</span> {order.price}
                </li>
              ))}
            </ul>
          </li>
        ))}
      </ul>
    </div>
  );
  /* const [orders, setOrders] = useState([]);

  useEffect(() => {
     // Fetch orders from your backend
     const fetchOrders = async () => {
      try {
        const response = await axios.get('http://localhost:3001/oders/');
        setOrders(response.data);  // Assuming your API returns an array of orders
      } catch (error) {
        console.error('Error fetching orders:', error);
      }
    }; 

    fetchOrders();
  }, []); // Run this effect only once when the component mounts

  return (
    <div className="background_image-other">
      <h1> Admin dash</h1>
      <ul class="order-list">
  {orders.map((order) => (
    <li>
      <span class="label">Gas Type:</span> {order.name  } , 
      <span class="label">Gas Size:</span> {order.size  } , 
      <span class="label">Count:</span> {order.count  }   , 
      <span class="label">Price:</span> {order.price  }
    </li>
  ))}
</ul>


    </div>
  ); */


//};
 

/*
<ul>
        {orders.map((order) => (
          <li>
            Gas Type: {order.name},Gas Size: {order.size}, Count: {order.count}, Price: {order.price}
          </li>
        ))}
      </ul> 
      */

      import 'bootstrap/dist/css/bootstrap.min.css';

 import React, { useState, useEffect } from 'react';
import axios from 'axios';

export const AdminDashboard = () => {
  const [usersWithOrders, setUsersWithOrders] = useState([]);

  useEffect(() => {
    const fetchUsersWithOrders = async () => {
      try {
        const response = await axios.get('http://localhost:3001/user/');
        setUsersWithOrders(response.data);
      } catch (error) {
        console.error('Error fetching users with orders:', error);
      }
    };

    fetchUsersWithOrders();
  }, []);

  const handleDeleteUser = async (userId) => {
    try {
      await axios.delete(`http://localhost:3001/user/${userId}`);
      // Update the user list after deletion
      setUsersWithOrders(usersWithOrders.filter(user => user.user._id !== userId));
    } catch (error) {
      console.error('Error deleting user:', error);
    }
  };

  const handleDeleteOrder = async ( userId,orderId) => {
    try {
      await axios.delete(`http://localhost:3001/orders/savedOders/${userId}/${orderId}`);
      // Update the order list after deletion
      setUsersWithOrders(usersWithOrders.map(user => ({
        ...user,
        savedOders: user.savedOders.filter(order => order._id !== orderId)
      })));
    } catch (error) {
      console.error('Error deleting order:', error);
    }
  };

  return (
    <div className='custom-container'>
      <h2>Users with Orders</h2>
      <ul className="order-list">
        {usersWithOrders.map((user) => (
          <li key={user.user._id}>
            <span className="label">Name:</span> {user.user.name}, <span className="label">Email:</span> {user.user.email}
            <button onClick={() => handleDeleteUser(user.user._id)}>Delete User</button>
            <ul className="order-list_item">
              {user.savedOders.map((order) => (
                <li key={order._id}>
                  <span className="label">Order Name:</span> {order.name},<br/>
                   <span className="label">Size:</span> {order.size},<br/> 
                  <span className="label">Count:</span> {order.count}, <br/>
                  <span className="label">Price:</span> {order.price}<br/>
                  <button onClick={() => handleDeleteOrder(user.user._id, order._id)}>Delete Order</button>
                </li>
              ))}
            </ul>
          </li>
        ))}
      </ul>
    </div>
  );
};
