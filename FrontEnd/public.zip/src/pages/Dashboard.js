import React, { useState, useEffect } from 'react';

export const Dashboard = () => {
  const [count, setCount] = useState(0);
  const [selectedType, setSelectedType] = useState('');
  const [selectedSize, setSelectedSize] = useState('');
  const [price, setPrice] = useState(0);
 // const [name,setName] = useState('');

 const [shippingAddress, setShippingAddress] = useState({
    name: '',
    address: '',
    city: '',
    state: '',
    zip: ''
  });

  const handleTypeChange = (event) => {
    setSelectedType(event.target.value);
  };

  const handleSizeChange = (event) => {
    setSelectedSize(event.target.value);
  };

  const handleAddressChange = (event) => {
    const { name, value } = event.target;
    setShippingAddress({ ...shippingAddress, [name]: value });
  };

  const handleSubmit = (event) => {
    event.preventDefault();

    // Simulate sending shipping address to the backend
    console.log('Shipping Address:', shippingAddress);
  };
  useEffect(() => {
    // Calculate price based on selected type, size, and count
    const calculatePrice = () => {
      let typePrice = 0;
      let sizePrice = 0;

      // Assign prices based on selected type and size
      switch (selectedType) {
        case 'Litro':
          typePrice = 100;  // Adjust the price based on your requirement
          break;
        case 'Laugh':
          typePrice = 98;  // Adjust the price based on your requirement
          break;
        case 'Cypetco':
          typePrice = 120;  // Adjust the price based on your requirement
          break;
        default:
          typePrice = 0;
      }

      switch (selectedSize) {
        case '5':
          sizePrice = 15;  // Adjust the price based on your requirement
          break;
        case '8':
          sizePrice = 24;  // Adjust the price based on your requirement
          break;
        case '12.5':
          sizePrice = 37;  // Adjust the price based on your requirement
          break;
        default:
          sizePrice = 0;
      }

      // Calculate total price
      const totalPrice = typePrice * sizePrice * count;
      setPrice(totalPrice);
    };

    calculatePrice();
  }, [selectedType, selectedSize, count]);

  return (
    <div className="background_image-other">
     
     <div className="container">
      <div className="selection">
      <h2>Select</h2>
        <p>Please select your favorite type:</p>
        <select value={selectedType} onChange={handleTypeChange}>
          <option value="">Select a type</option>
          <option value="Litro">Litro</option>
          <option value="Laugh">Laugh</option>
          <option value="Cypetco">Cypetco</option>
        </select>

        <p>Please select your favorite size:</p>
        <select value={selectedSize} onChange={handleSizeChange}>
          <option value="">Select a size</option>
          <option value="5">5 Kg</option>
          <option value="8">8 Kg</option>
          <option value="12.5">12.5 Kg</option>
        </select>

        <div className="countselector">
          <h3>{count}</h3>
          <button onClick={() => setCount(count + 1)}>+</button>
          <button onClick={() => setCount(count > 0 ? count - 1 : 0)}>-</button>
        </div>

        <div>
        <h5>Price: {price}</h5>
        
      </div>
      </div>
      <div className="shippingAddress">
        <h2>Shipping Address</h2>
        <form onSubmit={handleSubmit}>
          <div className='mb-3'>
            <label htmlFor="name">Name:</label>
            <input type="text" placeholder='Enter Name' name="name" onChange={handleAddressChange} />
          </div>
          <div className='mb-3'>
            <label htmlFor="address">Address:</label>
            <input type="text" placeholder='Enter Address' name="address" onChange={handleAddressChange} />
          </div>
          <div className='mb-3'>
            <label htmlFor="city">City:</label>
            <input type="text" placeholder='Enter City' name="city" onChange={handleAddressChange} />
          </div>
          
          <div className='mb-3'>
            <label htmlFor="zip">Zip Code:</label>
            <input type="text" placeholder='Enter Zip Code' name="zip" onChange={handleAddressChange} />
          </div>
          
        </form>
      </div>
      </div>
      <button type="submit">Order</button>
      <div>
        Contact Us
        <p>
          073872981
          <br />
          sfskgsv, csgs, uhc
          <br />
          cksvt@gmail.com
        </p>
      </div>
    </div>
  );
};
