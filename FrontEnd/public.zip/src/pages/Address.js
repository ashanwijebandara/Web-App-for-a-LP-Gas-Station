
export const Address = () =>{
    return(
        <div className="background_image-other">
                <h1> address</h1>
                <h3> oder details </h3>
        </div>
        
    );
};