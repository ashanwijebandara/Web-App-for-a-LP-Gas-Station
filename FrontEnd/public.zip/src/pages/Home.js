import { Link } from "react-router-dom";


export const Home =() =>{
    return (
     <div className="background-img">  
     <h1>Home </h1>

     <div>
        <button>Get Started</button>
        <Link to="/login"> LogIn </Link>
     </div> 
    </div>
  
    );
    
    
};