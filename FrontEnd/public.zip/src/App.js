
import './App.css';
import 'bootstrap/dist/css/bootstrap.css';
/* import { useState } from 'react'; */
import{BrowserRouter as Router,Routes,Route} from "react-router-dom";
import { Home } from './pages/Home';
import { LogIn } from './pages/LogIn';
import { SignUp } from './pages/SignUP';
import { Navbar } from './controllers/Navbar';
import { Dashboard } from './pages/Dashboard';
import { PaymentMethod } from './pages/PaymentMethod';
import { Address } from './pages/Address';
import { ThankYou } from './pages/ThankYou';
import { AdminDashboard } from './pages/AdminDash';

function App() {

  /* const[textColor,setTextColor] = useState("Black"); */
  
  

  return (<div className="App">
        {/* <button onClick={()=>{
          
          setTextColor(textColor === "Black" ? "red" : "Black"
        
        )}}>
          Show/Hide
          </button>


        <h1 style={{color:textColor}}>Hello</h1> */}


        


        <div className="navbar">
          <Router>
            <Navbar/>
            <Routes>
              <Route path="/home" element ={<Home/>} />
              <Route path="/login" element ={<LogIn/>} />
              <Route path="/signup" element ={<SignUp/>} />
              <Route path="/dashboard" element={ <Dashboard/>}/>
              <Route path="/paymentmethord" element = {<PaymentMethod/>} />
              <Route path="/adress" element={<Address/>}/>
              <Route path="/thankyou" element={<ThankYou/>}/>
              <Route path="/admin" element={<AdminDashboard/>}/>
              <Route path="*" element={<h2>Default</h2>}/>
              
            </Routes>
          </Router>
        </div>
        <footer>
          <p>&copy;2023.LP  Gas Staion</p>
        </footer>

      </div>
        
    
  );
}

export default App;
